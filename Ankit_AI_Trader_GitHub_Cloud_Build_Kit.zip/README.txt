# Ankit AI Trader — GitHub Cloud APK Build Kit

This kit lets GitHub Actions compile the Android APK in the cloud. Android Studio, Flutter and Android SDK do not need to be installed on your Windows laptop.

## What is included
- `Ankit_AI_Trader_Android_V1_1_Background_Source.zip` — the app source package.
- `.github/workflows/build-apk.yml` — a manual cloud-build workflow.

## Setup (GitHub website only)

1. Sign in to https://github.com/.
2. Create a **private** repository, for example `ankit-ai-trader`.
3. At the repository root, choose **Add file → Upload files** and upload:
   `Ankit_AI_Trader_Android_V1_1_Background_Source.zip`
4. Choose **Add file → Create new file**.
5. In the filename box, enter exactly:
   `.github/workflows/build-apk.yml`
6. Open the `build-apk.yml` file included in this kit, copy all its contents, and paste it into GitHub's editor.
7. Commit the files to the `main` branch.
8. Open the repository's **Actions** tab.
9. Select **Build Ankit AI Trader APK**.
10. Select **Run workflow** → **Run workflow**.
11. Open the completed run and download the `Ankit_AI_Trader_APK` artifact.
12. Extract the downloaded artifact ZIP. It contains `Ankit_AI_Trader.apk`.

## Important
- The workflow currently produces a personally installable test APK signed with the debug signing key. It is not a Play Store release signing setup.
- The app is still a UI/background-service prototype. It does not yet connect to CoinDCX, fetch live prices, or perform paper/live trades.
- The workflow may reveal additional source or dependency issues; inspect the build log if it fails.
- Keep the repository private. Never commit API keys, passwords, OTPs or wallet secrets.
- GitHub Actions is not a place to store exchange credentials.

The workflow generates missing Flutter Android wrapper files, preserves the app's custom Kotlin/manifest files, patches the known literal `\n` manifest issue, and attempts the release APK build.
